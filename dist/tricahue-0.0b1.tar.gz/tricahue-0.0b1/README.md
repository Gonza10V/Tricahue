# Tricahue
This package extracts experimental data and metadata, converts to stardard formats, uploads to SynBioHub and Flapjack, and connects them
